module KT
  module UI
    module Layout
      # ✅ SRP: Row component
      def ui_row(children:, class: "")
        content_tag(:div, children, class: "kt-row #{class}")
      end
    end
  end
end