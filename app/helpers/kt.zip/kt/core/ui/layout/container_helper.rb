module KT
  module UI
    module Layout

      # ✅ SRP: Container component
      def ui_container(children:, class: "")
        content_tag(:div, children, class: "kt-container #{class}")
      end

  
    end
  end
end

