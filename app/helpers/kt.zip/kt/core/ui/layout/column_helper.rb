module KT
  module UI
    module Layout
      # ✅ SRP: Column component
      def ui_column(children:, class: "")
        content_tag(:div, children, class: "kt-column #{class}")
      end
    end
  end
end